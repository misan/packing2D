#pragma once

#include "primitives/MArea.h"
#include "primitives/Rectangle.h"
#include <vector>
#include <optional>

// Forward declaration for the test fixture to be declared as a friend.
class BinTest;

/**
 * @brief Class used to describe a Bin object.
 * Equivalent to org.packing.core.Bin.
 */
class Bin {
public:
    friend class BinTest; // Grant access to the test fixture
    /**
     * @brief Initializes this bin with the specified dimensions.
     * @param dimension The rectangle defining the bin's boundaries.
     */
    Bin(const Rectangle2D& dimension);

    /**
     * @brief Get the placed pieces.
     */
    const std::vector<MArea>& getPlacedPieces() const;

    /**
     * @brief Get the number of pieces placed.
     */
    size_t getNPlaced() const;

    /**
     * @brief Computes the occupied area as the sum of areas of the placed pieces.
     */
    double getOccupiedArea() const;

    /**
     * @brief Get the dimensions.
     */
    const Rectangle2D& getDimension() const;

    /**
     * @brief Computes the empty area as the total area minus the occupied area.
     */
    double getEmptyArea() const;

    /**
     * @brief Places pieces inside the bin using the maximal rectangles strategy.
     * This is the C++ version of the `boundingBoxPacking` method from the original Java code.
     * @param piecesToPlace A list of pieces to try and place in the bin. The list will be sorted.
     * @return A vector of pieces that could not be placed.
     */
    std::vector<MArea> boundingBoxPacking(std::vector<MArea>& piecesToPlace);

    /**
     * @brief Compress all placed pieces in this bin towards the lower-left corner.
     */
    void compress();

    /**
     * @brief Drops pieces from the top of the bin to find a valid, non-occupied position.
     * @param piecesToDrop A list of pieces to try and place in the bin.
     * @return A vector of pieces that could not be placed.
     */
    std::vector<MArea> dropPieces(const std::vector<MArea>& piecesToDrop);

    /**
     * @brief Tries to place already placed pieces inside other placed pieces.
     * This is the C++ version of the `moveAndReplace` method from the original Java code.
     * @param indexLimit The starting index (from the end) to check for pieces to move.
     * @return True if any piece was moved, false otherwise.
     */
    bool moveAndReplace(size_t indexLimit);

private:
    Rectangle2D dimension;
    std::vector<MArea> placedPieces;
    std::vector<Rectangle2D> freeRectangles;

    /**
     * @brief Represents a potential placement for a piece, telling the caller
     * which free rectangle to use and if a rotation is needed.
     * This is a safer, more explicit C++ alternative to the side-effect-based
     * approach in the original Java code.
     */
    struct Placement {
        int rectIndex = -1;         // Index in freeRectangles, -1 if no fit found.
        bool requiresRotation = false; // Whether the piece needs to be rotated 90 degrees.
    };

    /**
     * @brief Finds the best free rectangle to place a piece in based on the minimal-wastage heuristic.
     * @param piece The piece to place.
     * @return A Placement struct with details of the best position.
     */
    Placement findWhereToPlace(const MArea& piece);

    /**
     * @brief Divides the rectangular space where a piece was just placed.
     * @param usedFreeArea Rectangular area that contains the newly placed piece.
     * @param justPlacedPieceBB Bounding box of the newly placed piece.
     */
    void splitScheme(const Rectangle2D& usedFreeArea, const Rectangle2D& justPlacedPieceBB);

    /**
     * @brief Recalculates the free rectangular boxes in the bin after a piece has been placed.
     * @param justPlacedPieceBB Bounding box of the piece that was just added.
     */
    void computeFreeRectangles(const Rectangle2D& justPlacedPieceBB);

    /**
     * @brief Eliminates all non-maximal boxes from the empty spaces in the bin.
     */
    void eliminateNonMaximal();

    /**
     * @brief Helper to compress a single piece towards a direction, avoiding collisions.
     * @param collisionArea Other pieces in the bin.
     * @param compressArea The piece to move.
     * @param vector The direction of compression (e.g., (-1, -1) for bottom-left).
     * @return True if the piece was moved, false otherwise.
     */
    bool compress(MArea& collisionArea, MArea& compressArea, const MVector& vector);

    /**
     * @brief Moves a piece downwards from the top of the bin, sliding horizontally to find a starting slot.
     * @param toDive The piece to drop.
     * @param collisionArea The area occupied by other pieces.
     * @return An optional containing the placed piece if successful, otherwise std::nullopt.
     */
    std::optional<MArea> dive(MArea toDive, MArea& collisionArea);

    /**
     * @brief Sweeps a piece along the interior of a container searching for a non-overlapping position.
     * @param container The piece that contains the free space.
     * @param inside The piece to place inside the container (passed by value as it's modified).
     * @param collisionArea Other pieces in the bin to avoid.
     * @return An optional containing the placed piece if successful, otherwise std::nullopt.
     */
    std::optional<MArea> sweep(const MArea& container, MArea inside, const MArea& collisionArea);
};
