#include "BinPacking.h"
#include <algorithm>
#include <iostream>

namespace BinPacking {

std::vector<Bin> pack(std::vector<MArea>& pieces, const Rectangle2D& binDimension) {
    std::vector<Bin> bins;

    // Sort pieces by area, largest first.
    // The original Java code sorts ascending and iterates backwards.
    // std::sort with a custom lambda for descending order is cleaner.
    std::sort(pieces.begin(), pieces.end(), [](const MArea& a, const MArea& b) {
        return a.getArea() > b.getArea();
    });

    std::vector<MArea> toPlace = pieces;

    while (!toPlace.empty()) {
        std::cout << "Creating a new bin. " << toPlace.size() << " pieces remaining." << std::endl;
        bins.emplace_back(binDimension);
        Bin& currentBin = bins.back();
        size_t nPiecesBefore = currentBin.getNPlaced(); // Will be 0 for a new bin

        // --- This block implements the multi-stage packing for a single bin ---

        // Stage 1: Initial packing using bounding boxes.
        std::vector<MArea> stillNotPlaced = currentBin.boundingBoxPacking(toPlace);

        // Stage 2: Iteratively optimize and repack (emulates BBCompleteStrategy).
        if (currentBin.getNPlaced() > nPiecesBefore) { // Only optimize if we actually placed something.
            while (true) {
                size_t piecesInBin = currentBin.getNPlaced();

                // Try to optimize the layout by moving pieces
                bool moved = currentBin.moveAndReplace(nPiecesBefore);

                if (!stillNotPlaced.empty()) {
                    stillNotPlaced = currentBin.boundingBoxPacking(stillNotPlaced);
                }
                // If no pieces were moved and no new pieces were added, the layout is stable.
                if (!moved && currentBin.getNPlaced() == piecesInBin) {
                    break;
                }
            }
        }

        // Stage 3: Final compression and drop pass to fill any remaining gaps.
        currentBin.compress();
        if (!stillNotPlaced.empty()) {
            stillNotPlaced = currentBin.dropPieces(stillNotPlaced);
        }
        currentBin.compress();

        // --- End of single-bin packing ---

        // If the bin is still empty, it means the largest remaining piece is too big.
        // We must break to avoid an infinite loop.
        if (currentBin.getNPlaced() == nPiecesBefore) {
            std::cerr << "Warning: Could not place any of the " << toPlace.size()
                      << " remaining pieces into a new bin. The largest piece might be too big." << std::endl;
            bins.pop_back(); // Remove the unused bin.
            break;
        }

        toPlace = stillNotPlaced;
    }

    return bins;
}

} // namespace BinPacking