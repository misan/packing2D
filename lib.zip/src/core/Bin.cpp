#include "Bin.h"
#include "primitives/Rectangle.h" // For RectangleUtils
#include "core/Constants.h"
#include <limits>
#include <algorithm>
#include <numeric>

Bin::Bin(const Rectangle2D& dimension) : dimension(dimension) {
    // The bin initially contains one large free rectangle covering its entire area.
    freeRectangles.push_back(dimension);
    // placedPieces is implicitly initialized as an empty vector.
}

const std::vector<MArea>& Bin::getPlacedPieces() const {
    return placedPieces;
}

size_t Bin::getNPlaced() const {
    return placedPieces.size(); // Replaces the NPlaced member variable
}

const Rectangle2D& Bin::getDimension() const {
    return dimension;
}

double Bin::getOccupiedArea() const {
    // Note: The original Java code calls updateArea() on each piece here.
    // Our MArea::getArea() is const and returns the cached value, which is updated
    // after any transformation. This should be sufficient.
    double totalArea = 0.0;
    for (const auto& piece : placedPieces) {
        totalArea += piece.getArea();
    }
    return totalArea;
    // A more functional approach using std::accumulate:
    // return std::accumulate(placedPieces.begin(), placedPieces.end(), 0.0,
    //     [](double sum, const MArea& piece) {
    //         return sum + piece.getArea();
    //     });
}

double Bin::getEmptyArea() const {
    double binArea = RectangleUtils::getWidth(dimension) * RectangleUtils::getHeight(dimension);
    return binArea - getOccupiedArea();
}

Bin::Placement Bin::findWhereToPlace(const MArea& piece) {
    Placement bestPlacement;
    double minWastage = std::numeric_limits<double>::max();
    Rectangle2D pieceBB = piece.getBoundingBox2D();

    // Iterate backwards, similar to the original Java implementation, to check
    // recently added free rectangles first.
    for (int i = static_cast<int>(freeRectangles.size()) - 1; i >= 0; --i) {
        const auto& freeRect = freeRectangles[i];

        // 1. Check if the piece fits without rotation
        if (RectangleUtils::fits(pieceBB, freeRect)) {
            double wastage = std::min(
                RectangleUtils::getWidth(freeRect) - RectangleUtils::getWidth(pieceBB),
                RectangleUtils::getHeight(freeRect) - RectangleUtils::getHeight(pieceBB)
            );
            if (wastage < minWastage) {
                minWastage = wastage;
                bestPlacement.rectIndex = i;
                bestPlacement.requiresRotation = false;
            }
        }

        // 2. Check if the piece fits with a 90-degree rotation
        if (RectangleUtils::fitsRotated(pieceBB, freeRect)) {
            // Note: piece dimensions are swapped for wastage calculation
            double wastage = std::min(
                RectangleUtils::getWidth(freeRect) - RectangleUtils::getHeight(pieceBB),
                RectangleUtils::getHeight(freeRect) - RectangleUtils::getWidth(pieceBB)
            );
            if (wastage < minWastage) {
                minWastage = wastage;
                bestPlacement.rectIndex = i;
                bestPlacement.requiresRotation = true;
            }
        }
    }

    return bestPlacement;
}

std::vector<MArea> Bin::boundingBoxPacking(std::vector<MArea>& piecesToPlace) {
    std::vector<MArea> notPlacedPieces;

    // Create a single MArea representing all currently placed pieces to check for collisions.
    MArea totalPlacedArea;
    for (const auto& p : this->placedPieces) {
        totalPlacedArea.add(p);
    }

    // Sort pieces by area, descending.
    std::sort(piecesToPlace.begin(), piecesToPlace.end(), [](const MArea& a, const MArea& b) {
        return a.getArea() > b.getArea();
    });

    for (const auto& piece : piecesToPlace) {
        Placement placement = findWhereToPlace(piece);

        if (placement.rectIndex != -1) {
            const Rectangle2D& freeRect = freeRectangles[placement.rectIndex];
            MArea placedPiece = piece; // Create a copy to place.

            if (placement.requiresRotation) {
                placedPiece.rotate(90);
            }

            // Place at the bottom-left corner of the free rectangle.
            placedPiece.placeInPosition(RectangleUtils::getX(freeRect), RectangleUtils::getY(freeRect));

            if (!placedPiece.intersection(totalPlacedArea)) {
                Rectangle2D pieceBB = placedPiece.getBoundingBox2D();

                // The original Java code used one of two schemes. The `computeFreeRectangles`
                // is the more general and robust one. Calling both was incorrect.
                computeFreeRectangles(pieceBB);
                eliminateNonMaximal();

                this->placedPieces.push_back(placedPiece);
                totalPlacedArea.add(placedPiece);
            } else {
                notPlacedPieces.push_back(piece);
            }
        } else {
            notPlacedPieces.push_back(piece);
        }
    }
    return notPlacedPieces;
}

void Bin::splitScheme(const Rectangle2D& usedFreeArea, const Rectangle2D& justPlacedPieceBB) {
    // Remove the rectangle that was just used.
    auto new_end = std::remove_if(freeRectangles.begin(), freeRectangles.end(),
        [&](const Rectangle2D& r) {
            return r.min_corner() == usedFreeArea.min_corner() && r.max_corner() == usedFreeArea.max_corner();
        });
    freeRectangles.erase(new_end, freeRectangles.end());

    // Add the new free rectangle above the placed piece.
    double topHeight = RectangleUtils::getMaxY(usedFreeArea) - RectangleUtils::getMaxY(justPlacedPieceBB);
    if (topHeight > 1e-9) {
        freeRectangles.emplace_back(
            MPointDouble(RectangleUtils::getX(usedFreeArea), RectangleUtils::getMaxY(justPlacedPieceBB)),
            MPointDouble(RectangleUtils::getMaxX(usedFreeArea), RectangleUtils::getMaxY(usedFreeArea))
        );
    }

    // Add the new free rectangle to the right of the placed piece.
    double rightWidth = RectangleUtils::getMaxX(usedFreeArea) - RectangleUtils::getMaxX(justPlacedPieceBB);
    if (rightWidth > 1e-9) {
        freeRectangles.emplace_back(
            MPointDouble(RectangleUtils::getMaxX(justPlacedPieceBB), RectangleUtils::getY(usedFreeArea)),
            MPointDouble(RectangleUtils::getMaxX(usedFreeArea), RectangleUtils::getMaxY(usedFreeArea))
        );
    }
}

void Bin::computeFreeRectangles(const Rectangle2D& justPlacedPieceBB) {
    std::vector<Rectangle2D> nextFreeRectangles;
    const double epsilon = 1e-9;

    for (const auto& freeR : freeRectangles) {
        if (!RectangleUtils::intersects(freeR, justPlacedPieceBB)) {
            nextFreeRectangles.push_back(freeR); // Keep it if it doesn't intersect.
        } else {
            // It intersects, so split it into up to 4 new rectangles.
            Rectangle2D rIntersection = RectangleUtils::createIntersection(freeR, justPlacedPieceBB);

            // Top
            double topHeight = RectangleUtils::getMaxY(freeR) - RectangleUtils::getMaxY(rIntersection);
            if (topHeight > epsilon) {
                nextFreeRectangles.emplace_back(
                    MPointDouble(RectangleUtils::getX(freeR), RectangleUtils::getMaxY(rIntersection)),
                    MPointDouble(RectangleUtils::getMaxX(freeR), RectangleUtils::getMaxY(freeR))
                );
            }
            // Bottom
            double bottomHeight = RectangleUtils::getY(rIntersection) - RectangleUtils::getY(freeR);
            if (bottomHeight > epsilon) {
                nextFreeRectangles.emplace_back(
                    MPointDouble(RectangleUtils::getX(freeR), RectangleUtils::getY(freeR)),
                    MPointDouble(RectangleUtils::getMaxX(freeR), RectangleUtils::getY(rIntersection))
                );
            }
            // Left
            double leftWidth = RectangleUtils::getX(rIntersection) - RectangleUtils::getX(freeR);
            if (leftWidth > epsilon) {
                nextFreeRectangles.emplace_back(
                    MPointDouble(RectangleUtils::getX(freeR), RectangleUtils::getY(freeR)),
                    MPointDouble(RectangleUtils::getX(rIntersection), RectangleUtils::getMaxY(freeR))
                );
            }
            // Right
            double rightWidth = RectangleUtils::getMaxX(freeR) - RectangleUtils::getMaxX(rIntersection);
            if (rightWidth > epsilon) {
                nextFreeRectangles.emplace_back(
                    MPointDouble(RectangleUtils::getMaxX(rIntersection), RectangleUtils::getY(freeR)),
                    MPointDouble(RectangleUtils::getMaxX(freeR), RectangleUtils::getMaxY(freeR))
                );
            }
        }
    }
    freeRectangles = nextFreeRectangles;
}

void Bin::eliminateNonMaximal() {
    // Sort by area descending as an optimization, so a smaller rect is less likely
    // to be contained in a rect that comes after it in the list.
    std::sort(freeRectangles.begin(), freeRectangles.end(), [](const Rectangle2D& a, const Rectangle2D& b) {
        return (RectangleUtils::getWidth(a) * RectangleUtils::getHeight(a)) > (RectangleUtils::getWidth(b) * RectangleUtils::getHeight(b));
    });

    auto& rects = freeRectangles; // Use an alias for clarity
    if (rects.size() < 2) return;

    auto new_end = std::remove_if(rects.begin(), rects.end(),
        [&](const Rectangle2D& r1) {
            // A rectangle is non-maximal if it is contained by any other rectangle.
            return std::any_of(rects.begin(), rects.end(),
                [&](const Rectangle2D& r2) {
                    // A rect is contained if it's not the same rect and r2 contains r1.
                    // Comparing pointers to avoid comparing a rect with itself.
                    return (&r1 != &r2) && RectangleUtils::contains(r2, r1);
                });
        });

    rects.erase(new_end, rects.end());
}

void Bin::compress() {
    if (placedPieces.empty()) {
        return;
    }

    MArea total;
    for (const auto& p : placedPieces) {
        total.add(p);
    }

    bool moved_in_pass = true;
    while (moved_in_pass) {
        moved_in_pass = false;
        for (auto& piece : placedPieces) {
            total.subtract(piece); // Temporarily remove piece from collision set

            // In C++ (Y-up), moving to bottom-left is (-1, -1).
            // The original Java code used a Y-down coordinate system.
            if (compress(total, piece, MVector(-1.0, -1.0))) {
                moved_in_pass = true;
            }
            total.add(piece); // Add it back for the next iteration
        }
    }
}

bool Bin::compress(MArea& collisionArea, MArea& compressArea, const MVector& vector) {
    if (vector.getX() == 0 && vector.getY() == 0) {
        return false;
    }

    int total_moves = 0;
    bool moved_in_iter = true;
    while (moved_in_iter) { // Loop as long as we can move the piece in any direction
        moved_in_iter = false; // Assume no movement in this pass

        // Prioritize Y movement
        if (vector.getY() != 0) {
            MVector u_y(0, vector.getY());
            compressArea.move(u_y);
            if (compressArea.isInside(this->dimension) && !compressArea.intersection(collisionArea)) {
                moved_in_iter = true; // A move was successful
                total_moves++;
            } else {
                compressArea.move(u_y.inverse());
            }
        }

        // Then, attempt X movement regardless of Y movement success
        if (vector.getX() != 0) {
            MVector u_x(vector.getX(), 0);
            compressArea.move(u_x);
            if (compressArea.isInside(this->dimension) && !compressArea.intersection(collisionArea)) {
                moved_in_iter = true; // A move was successful
                total_moves++;
            } else {
                compressArea.move(u_x.inverse());
            }
        }
    }
    return total_moves > 0;
}

std::vector<MArea> Bin::dropPieces(const std::vector<MArea>& piecesToDrop) {
    std::vector<MArea> unplacedPieces;
    MArea totalPlacedArea;
    for (const auto& p : this->placedPieces) {
        totalPlacedArea.add(p);
    }

    for (const auto& pieceToTry : piecesToDrop) {
        bool wasPlaced = false;
        for (int angle : Constants::ROTATION_ANGLES) {
            MArea candidate = pieceToTry;
            if (angle > 0) {
                // Create a new rotated version for each attempt
                candidate.rotate(static_cast<double>(angle));
            }

            std::optional<MArea> placedPiece = dive(candidate, totalPlacedArea);

            if (placedPiece) {
                this->placedPieces.push_back(*placedPiece);
                totalPlacedArea.add(*placedPiece);
                wasPlaced = true;
                break; // Successfully placed, move to the next piece
            }
        }
        if (!wasPlaced) {
            unplacedPieces.push_back(pieceToTry);
        }
    }
    return unplacedPieces;
}

std::optional<MArea> Bin::dive(MArea toDive, MArea& collisionArea) {
    Rectangle2D pieceBB = toDive.getBoundingBox2D();
    double pieceWidth = RectangleUtils::getWidth(pieceBB);
    double pieceHeight = RectangleUtils::getHeight(pieceBB);
    double binWidth = RectangleUtils::getWidth(this->dimension);
    double binHeight = RectangleUtils::getHeight(this->dimension);

    // Check if the piece can fit in the bin at all.
    if (pieceWidth > binWidth || pieceHeight > binHeight) {
        return std::nullopt;
    }

    double dx = pieceWidth / Constants::DIVE_HORIZONTAL_DISPLACEMENT_FACTOR;
    if (dx < 1e-9) { // Prevent very small or zero step size
        dx = 1.0;
    }

    // Slide the piece horizontally along the top of the bin.
    for (double initialX = 0; initialX + pieceWidth <= binWidth + 1e-9; initialX += dx) {
        MArea tempPiece = toDive; // Create a copy for this attempt

        // Place piece at the current horizontal position at the top of the bin.
        tempPiece.placeInPosition(initialX, binHeight - pieceHeight);

        if (!tempPiece.intersection(collisionArea)) {
            // This is a valid starting slot. Now, "drop" the piece by compressing it downwards.
            // The compress helper will move it down until it hits the floor or another piece.
            // In our Y-up system, "down" is a vector with a negative Y component.
            this->compress(collisionArea, tempPiece, MVector(0, -1.0));
            return tempPiece; // Successfully placed.
        }
    }

    // A special check for the rightmost position, in case dx skips it.
    MArea tempPiece = toDive;
    tempPiece.placeInPosition(binWidth - pieceWidth, binHeight - pieceHeight);
    if (!tempPiece.intersection(collisionArea)) {
        this->compress(collisionArea, tempPiece, MVector(0, -1.0));
        return tempPiece;
    }

    // If no starting position was found along the top edge, the piece cannot be placed.
    return std::nullopt;
}

bool Bin::moveAndReplace(size_t indexLimit) {
    bool movement = false;
    MArea total;
    for (const auto& area : this->placedPieces) {
        total.add(area);
    }

    for (int i = static_cast<int>(placedPieces.size()) - 1; i >= static_cast<int>(indexLimit); --i) {
        MArea& currentArea = placedPieces[i];
        total.subtract(currentArea);

        bool replaced = false;
        for (int j = 0; j < i; ++j) {
            const MArea& container = placedPieces[j];
            if (container.getFreeArea() > currentArea.getArea()) {
                Rectangle2D contBB = container.getBoundingBox2D();

                // Try without rotation
                MArea candidate = currentArea;
                candidate.placeInPosition(RectangleUtils::getX(contBB), RectangleUtils::getY(contBB));

                if (auto swept = sweep(container, candidate, total)) {
                    freeRectangles.push_back(currentArea.getBoundingBox2D());
                    compress(total, *swept, MVector(-1.0, -1.0));
                    placedPieces[i] = *swept;
                    computeFreeRectangles(swept->getBoundingBox2D());
                    eliminateNonMaximal();
                    movement = true;
                    replaced = true;
                    break;
                }

                // Try with rotation
                candidate = currentArea;
                candidate.rotate(90);
                candidate.placeInPosition(RectangleUtils::getX(contBB), RectangleUtils::getY(contBB));
                if (auto swept = sweep(container, candidate, total)) {
                    freeRectangles.push_back(currentArea.getBoundingBox2D());
                    compress(total, *swept, MVector(-1.0, -1.0));
                    placedPieces[i] = *swept;
                    computeFreeRectangles(swept->getBoundingBox2D());
                    eliminateNonMaximal();
                    movement = true;
                    replaced = true;
                    break;
                }
            }
        }
        // Add the piece back to the total collision area. If it was replaced,
        // placedPieces[i] now refers to the new piece.
        total.add(placedPieces[i]);
    }
    return movement;
}

std::optional<MArea> Bin::sweep(const MArea& container, MArea inside, const MArea& collisionArea) {
    // First check: can it be placed at the starting corner?
    // The 'inside' piece is already placed at the bottom-left of the container's bounding box by the caller.
    // We need to check for collision with other pieces AND with the container piece itself.
    if (!inside.intersection(collisionArea) && !inside.intersection(container)) {
        return inside;
    }

    Rectangle2D containerBB = container.getBoundingBox2D();
    Rectangle2D insideBB_orig = inside.getBoundingBox2D();

    double dx_factor = Constants::DX_SWEEP_FACTOR;
    double dy_factor = Constants::DY_SWEEP_FACTOR;

    // Complexity Guard: If the piece to be swept is very complex (high vertex count),
    // we perform a much coarser search to avoid a performance hang. This is a trade-off
    // between packing quality and performance for pathological cases.
    if (inside.getVertexCount() > 100) {
        dx_factor = 2; // Use a much smaller factor (larger steps)
        dy_factor = 1;
    }

    double dx = RectangleUtils::getWidth(insideBB_orig) / dx_factor;
    double dy = RectangleUtils::getHeight(insideBB_orig) / dy_factor;
    if (dx < 1e-9) dx = 1.0;
    if (dy < 1e-9) dy = 1.0;

    double startX = RectangleUtils::getX(containerBB);
    double startY = RectangleUtils::getY(containerBB);
    double endX = RectangleUtils::getMaxX(containerBB);
    double endY = RectangleUtils::getMaxY(containerBB);

    // Sweep horizontally, then vertically, inside the container's bounding box.
    // The 'inside' parameter is a copy, so we can move it freely.
    for (double y = startY; y + RectangleUtils::getHeight(insideBB_orig) <= endY + 1e-9; y += dy) {
        // For each row, sweep across horizontally
        for (double x = startX; x + RectangleUtils::getWidth(insideBB_orig) <= endX + 1e-9; x += dx) {
            inside.placeInPosition(x, y);

            // A valid placement must not intersect other pieces, must not intersect the container piece,
            // and must be within the bin's main dimensions.
            if (inside.isInside(this->dimension) && !inside.intersection(collisionArea) && !inside.intersection(container)) {
                return inside; // Found a valid position
            }
        }
    }

    return std::nullopt; // No valid position found
}